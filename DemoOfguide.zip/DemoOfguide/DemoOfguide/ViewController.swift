
import UIKit
import MYPassthrough

class ViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let lblDes = LabelDescriptor(for: "Select Image")
        lblDes.position = .bottom
        let holeDes = HoleDescriptor(frame: CGRect(x: 90, y: 35, width: 170, height: 105), type: .rect(cornerRadius: 10, margin: 10), forOrientation: .portrait)
        holeDes.labelDescriptor = lblDes
        let task = PassthroughTask(with: [holeDes])
        PassthroughManager.shared.display(tasks: [task])
        
        let lblDesc = LabelDescriptor(for: "Enter name")
        lblDesc.position = .bottom
        let holeDesc = HoleDescriptor(frame: CGRect(x: 55, y: 210, width: 100, height: 35), type: .rect(cornerRadius: 10, margin: 10), forOrientation: .portrait)
        holeDesc.labelDescriptor = lblDesc
        let task2 = PassthroughTask(with: [holeDesc])
        PassthroughManager.shared.display(tasks: [task2])
    }


}

