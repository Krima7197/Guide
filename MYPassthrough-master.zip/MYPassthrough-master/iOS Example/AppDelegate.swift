//
//  AppDelegate.swift
//  iOS Example
//
//  Created by Yaroslav Minaev on 23/09/2017.
//  Copyright © 2017 Minaev.pro. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {

        return true
    }
}

